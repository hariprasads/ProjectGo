// +build darwin

package socket

// For compile time compatibility
const AF_BLUETOOTH = 0
