// Package linux provides linux-specific support for gatt.
//
// This package is work in progress. We expect the APIs to change significantly before stabilizing.

package linux
